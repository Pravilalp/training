from odoo import fields, models


class InvitedUser(models.Model):
    _name = "invited.user"

    invited_user = fields.Char(string="Invited User")
    invited_user_mail = fields.Char(string="Invited User Mail")
    invitation_date = fields.Datetime(string="Invited Date")
    user_id = fields.Many2one('res.users', string="Referral user")


class InvitedPortal(models.Model):
    _inherit = "res.users"
    invited_user_line_ids = fields.One2many('invited.user', 'user_id', string="Invited User")
