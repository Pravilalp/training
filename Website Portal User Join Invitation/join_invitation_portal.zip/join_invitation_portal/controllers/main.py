import datetime
from datetime import datetime

from odoo import http
from odoo.http import request


class invitation(http.Controller):
    @http.route('/join_request', type='http', auth="public", website=True, csrf=False)
    def join_invitation_form(self, **kw):
        print("invitition....................")
        return http.request.render('join_invitation_portal.create_invitation', {})

    @http.route('/join_request/thanks', type='http', auth="public", website=True, csrf=False)
    def join_invitation_thanks(self, **kw):
        print("******************")
        print("data", kw)
        print("******************")

        vals = {
            'invited_user': kw.get('name'),
            'invited_user_mail': kw.get('email'),
            'user_id': http.request.env.context.get('uid'),
            'invitation_date': datetime.today()
        }
        value = request.env['invited.user'].sudo().create(vals)
        print('***value****', value.id)

        val = {
            'name': kw.get('name'),
            'login': kw.get('email'),
            'sel_groups_1_9_10': 9
        }
        users = request.env['res.users'].sudo().create(val)
        users.partner_id.write({'email': kw.get('email')})

        template = request.env.ref('join_invitation_portal.send_mail_invite_portal_users', False)
        request.env['mail.template'].browse(template.id).send_mail(value.id, force_send=True)

        return http.request.render('join_invitation_portal.create_thanks', {})


class portal_user_signup(http.Controller):
    @http.route('/portal_signup_page', type='http', auth="public", website=True, csrf=False)
    def join_invitation_form(self, **kw):
        print("***rerrererer*******", kw)

        print("invitition....................")
        return http.request.render('join_invitation_portal.portal_user_signup', {})

    @http.route('/portal_log', type='http', auth="public", website=True, csrf=False)
    def join_invitation(self, **kw):
        print("***rerrererer*******", kw)
        users = request.env['res.users'].sudo().search([('login', '=', kw.get('email'))])
        print("**userssssssssssssssss*******", users)

        users.write({'password': kw.get('password')})
        print("***partner****", users.password)

        print("invitition....................")
  
        return http.request.render('web.login', {})
